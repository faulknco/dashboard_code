import dash
import dash_html_components as html
import dash_bootstrap_components as dbc

from app import app


layout = html.Div([
    dbc.Container([
        dbc.Row([
            #Header span the whole row
            #className: Often used with CSS to style elements with common properties.
            dbc.Col(html.H1("Welcome To Connor's Dashboard", className="text-center")
                    , className="mb-5 mt-5")
        ]),
        dbc.Row([
            dbc.Col(html.H5(children='This web application shows analysis of genetic substructure using genome-wide SNPs. '
                                     )
                    , className="mb-4")
            ]),

        dbc.Row([
            dbc.Col(html.H5(children='It consists of two main pages: Exploratory, which gives all the principal component plotted against each-other, '
                                     'The next page will be the Explainatory page in which it explains some ideas behind this project.')
                    , className="mb-5")
        ]),

        dbc.Row([
            # 2 columns of width 6 with a border
            dbc.Col(dbc.Card(children=[html.H3(children='Go to the original dataset for more information on the dataset',
                                               className="text-center"),
                                       dbc.Button("1000 Genomes Project",
                                                  href="https://www.internationalgenome.org/",
                                                  color="primary",
                                                  className="mt-3"),
                                       ],
                             body=True, color="dark", outline=True)
                    , width=6, className="mb-4"),

            dbc.Col(dbc.Card(children=[html.H3(children='Access the code used to build this dashboard',
                                               className="text-center"),
                                       dbc.Button("GitHub",
                                                  href="https://github.com/connolls/dashappTeaching.git",
                                                  color="primary",
                                                  className="mt-3"),
                                       ],
                             body=True, color="dark", outline=True)
                    , width=6, className="mb-4"),

        ], className="mb-5"),
        dbc.Row([
            dbc.Col(html.Img(src=app.get_asset_url('population_table.png')),
            width={"size": 6, "offset": 4})
        ]),
        #html.A("A special mention to ",
               #href="https://www.dkit.ie/")

    ])

])

