# -*- coding: utf-8 -*-
"""
Created on Tue Apr 27 18:21:23 2021

@author: conno
"""




#import packages to create app
import dash
import dash_html_components as html
import dash_core_components as dcc
from dash.dependencies import Input, Output
import plotly.express as px
import pandas as pd
import numpy as np
from app import app
#import dash_bootstrap_components as dbc
import pathlib
#import dash_table

# needed only if running this as a single page app

#app = dash.Dash(__name__)


PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath("../datasets").resolve()

PCA_eigenval = pd.read_csv(DATA_PATH.joinpath("last_PCA.eigenval"), header=0, delimiter=r"\s+")
PCA_eigenvec = pd.read_csv(DATA_PATH.joinpath("last_PCA.eigenvec"), header=0, delimiter=r"\s+")


colors = {'background': '#e9eef5','text': '#1c1cbd'}
styles = { 'pre': { 'border': 'thin lightgrey solid', 'overflowX': 'scroll'}}

color_discrete_map = {'EAS': '#636EFA', 'AFR': '#EF553B', 'AMR': '#00CC96',
    'EUR': '#AB63FA', 'SAS': '#FFA15A'}

color_discrete_map_pop = {'CHN':'#0d0887', 'PRI':'#46039f', 'COL':'#7201a8', 'ESP':'#9c179e',  'PER':'#bd3786',  'IND':'#d8576b',
       'VNM':'#ed7953',  'BHS':'#fb9f3a' , 'GMB': '#fdca26', 'NGA':'#f0f921',  'BGD':'#FFA15A','SLE':'#636EFA', 'LKA':'#EF553B', 'USA':'#00CC96',
       'JPN':'#4f1b03', 'KEN':'#ffff4d', 'ITA':'#ff4dbe'}



############## ##################################################################################################
#PCA_eigenval = pd.read_csv(r"C:\Users\conno\OneDrive\Desktop\plink_win64_20201019\1000genomes_common\last_PCA.eigenval", header=0, delimiter=r"\s+")
#PCA_eigenvec = pd.read_csv(r"C:\Users\conno\OneDrive\Desktop\plink_win64_20201019\1000genomes_common\last_PCA.eigenvec", header=0, delimiter=r"\s+")
####################################################################################################################
 # dataframe hold pcs and id
PC_df = pd.DataFrame( PCA_eigenvec.iloc[:,1:].values ,columns=['Sample name','PC_1', 'PC_2', 'PC_3','PC_4','PC_5','PC_6','PC_7','PC_8',
                                                'PC_9','PC_10','PC_11','PC_12','PC_13','PC_14','PC_15',
                                                'PC_16','PC_17','PC_18','PC_19','PC_20','PC_21','PC_22','PC_23',
                                                'PC_24','PC_25','PC_26','PC_27','PC_28','PC_29','PC_30'])#, index = features)
#####################################################################################################################
#tsv_file=r'C:\Users\conno\Downloads\igsr_samples.tsv'
#csv_table=pd.read_table(tsv_file,sep='\t')
#csv_table.to_csv(r'C:\Users\conno\Downloads\igsr_samples.csv',index=False)
#################################################################################
Labels = pd.read_csv(DATA_PATH.joinpath("igsr_samples.csv"),usecols=[0,2,3,4,5,6])
#################################################################################
# this is for mnerging the pop names into the pc dataframe
List_labels = Labels[Labels['Sample name'].isin(PC_df['Sample name'])]
 ################################################################################
final_df = pd.merge(PC_df,List_labels, how='inner',  on='Sample name')
#new_df = final_df.infer_objects()
#################################################################################
relabeled = final_df.copy()
relabeled['Population code'].replace({'CHS': 'CHN', 'PUR': 'PRI', 'CDX': 'CHN', 'CLM': 'COL', 'IBS': 'ESP', 'PEL' :'PER', 'PJL': 'PAK',
       'KHV':'VNM', 'ACB': 'BHS' , 'GWD':'GMB' , 'ESN':'NGA', 'BEB': 'BGD', 'MSL':'SLE', 'STU': 'LKA', 'ITU':'IND', 'CEU':'GBR',
       'YRI':'NGA', 'CHB':'CHN', 'JPT':'JPN', 'LWK':'KEN', 'ASW': 'ZAF', 'MXL':'MEX', 'TSI':'ITA', 'GIH':'IND' },inplace=True)

relabeled['SampledFrom'] = relabeled['Population code'].replace({ 'STU': 'GBR', 'ITU':'GBR', 'CEU':'USA','ASW': 'USA', 'MXL':'USA', 'GIH':'USA' })

################################################################################
#find indina in uk
cont_names = relabeled['Superpopulation code'].unique()
contries_names = relabeled['Population code'].unique()
PC_LIST = relabeled.iloc[:,1:31]
cols = list(relabeled.columns)
#tables__ =  pd.DataFrame( cont_names, contries_names) #relabeled.iloc[:,32:33].unique()
poptable = relabeled['Population code'].value_counts()
conttable = relabeled['Superpopulation code'].value_counts()
################################################################################

exp_var_cumul = (PCA_eigenval/PCA_eigenval.sum()*100).cumsum()
var = px.area(x=exp_var_cumul.index, y=exp_var_cumul.iloc[:,0],
              labels={"x": "# Components", "y": "Explained Variance"},title = 'Total Variance Explain by the Principal Components')
############################################


# bootstrap theme
# https://bootswatch.com/spacelab/
#external_stylesheets = [dbc.themes.SPACELAB]


#app = dash.Dash(__name__, external_stylesheets=external_stylesheets)


# change to app.layout if running as single page app instead
layout = html.Div(style={'backgroundColor': colors['background']},children=[
    html.H1('Analysis of genetic substructure using genome-wide SNP',
            style={'textAlign': 'center','color': colors['text']}),

   #############################################################################################################################################
    html.Div('''This Page Shows The data  Classified As CLusters of Superpopulation ''', style={'textAlign': 'center','color': colors['text']}),
#################################################################################################################################
    html.Div([
        html.Div([
            html.Label('Select Superpopulation'),
                        dcc.Dropdown(id='cont_dropdown',
                                     options=[{'label': i, 'value': i}
                                              for i in cont_names],value=['AMR','EUR','AFR','EAS','SAS'],multi=True)],
                       style={'width': '68%','display': 'inline-block'}),

        html.Div(
              dcc.Graph(id='PCA',
              style={'width': '49%','float': 'left', 'display': 'inline-block'}
              ),
              ),
        html.Div(
              dcc.Graph(id='MAP',
              style={'width': '49%','float': 'right', 'display': 'inline-block'}
              ),
              ),
        html.Div(
              dcc.Graph(id='counts',
              style={'width': '49%','float': 'left', 'display': 'inline-block'} #'width': '68%',
              ),
              ),
        html.Div(
            dcc.Graph( id='var',figure =var ,
                      style={'width': '49%','float': 'right', 'display': 'inline-block'})
            )
        ])
    ])


##########################################
@app.callback(
    [dash.dependencies.Output('PCA', 'figure'),
     dash.dependencies.Output('MAP', 'figure'),
    dash.dependencies.Output('counts', 'figure')],
    [dash.dependencies.Input('cont_dropdown', 'value')])
     #dash.dependencies.Input('radio', 'value')])

###############################################################
#selected_cont = ['EUR','SAS']
def update_map(selected_cont):
    ' map being updated'
    if not (selected_cont ):
        return dash.no_update
    data =[]
    for j in selected_cont:
            data.append(relabeled[relabeled['Superpopulation code'] == j])
    df = pd.DataFrame(np.concatenate(data), columns=list(relabeled.columns))
    df=df.infer_objects()
    ###########################################################################
    fig = px.scatter_3d(df, x='PC_1', y='PC_2', z='PC_3', color='Superpopulation code',
    #hover_name=['Population name'],
    color_discrete_map = color_discrete_map, opacity=0.65,
    labels={'Population name':'Population','Superpopulation code':'Superpopulation'})
    fig.update_layout( title_text ='3D Principal Component Plot') #width=800, height = 600,
    #not title can have one
###############################################################################


    map_fig= px.choropleth(df,locations='Population code', color='Superpopulation code',
                       hover_name='Population name',hover_data=['Population code','Superpopulation name'],
                       color_discrete_map=color_discrete_map,
                       labels={'Population name':'Population','Superpopulation code':'Superpopulation'})
    map_fig.update_layout( plot_bgcolor='rgb(255, 255, 255)',paper_bgcolor='rgb(255, 255, 255)',#width=800, height = 600
                          title_text="Location of Sample's Ancestry")
    #map_fig.update_layout(width=600, height = 800)
##############################################################################
    countsaxis  = df['Superpopulation code'].value_counts()
    fig4 = px.bar(df, x = countsaxis.index, y= countsaxis.values, color=countsaxis.index,
                  text=countsaxis.values, labels= {'x':'Population','y':'Frequencies of Sample'}, color_discrete_map = color_discrete_map)
    fig4.update_layout(plot_bgcolor='rgb(255, 255, 255)',paper_bgcolor='rgb(255, 255, 255)',
                       title_text="Frequencies From Different Superpopulations")


#################################################
    return [fig, map_fig , fig4]

################################################################################





#if __name__ == '__main__':
 #   app.run_server(port=8070,debug=True)

