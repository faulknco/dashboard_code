# -*- coding: utf-8 -*-
"""
Created on Tue Apr 27 14:36:18 2021

@author: conno
"""





#import packages to create app
import dash
import dash_html_components as html
import dash_core_components as dcc
from dash.dependencies import Input, Output
import plotly.express as px
import pandas as pd
from app import app
import pathlib
import dash_bootstrap_components as dbc

# needed only if running this as a single page app

PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath("../datasets").resolve()

PCA_eigenval = pd.read_csv(DATA_PATH.joinpath("last_PCA.eigenval"), header=0, delimiter=r"\s+")
PCA_eigenvec = pd.read_csv(DATA_PATH.joinpath("last_PCA.eigenvec"), header=0, delimiter=r"\s+")


colors = {'background': '#e9eef5','text': '#1c1cbd'}
styles = { 'pre': { 'border': 'thin lightgrey solid', 'overflowX': 'scroll'}}



color_discrete_map = {'EAS': '#636EFA', 'AFR': '#EF553B', 'AMR': '#00CC96',
    'EUR': '#AB63FA', 'SAS': '#FFA15A'}

color_discrete_map_pop = {'CHN':'#0d0887', 'PRI':'#46039f', 'COL':'#7201a8', 'ESP':'#ff4dbe',  'PER':'#bd3786',  'IND':'#00e9f5',
       'VNM':'#ed7953',  'BHS':'#fb9f3a' , 'GMB': '#fdca26', 'NGA':'#d8576b',  'BGD':'#FFA15A','SLE':'#636EFA', 'LKA':'#EF553B', 'USA':'#00CC96',
       'JPN':'#4f1b03', 'KEN':'#ffff4d', 'ITA':'#55ff00'}



############## ##################################################################################################
#PCA_eigenval = pd.read_csv(r"C:\Users\conno\OneDrive\Desktop\plink_win64_20201019\1000genomes_common\last_PCA.eigenval", header=0, delimiter=r"\s+")
#PCA_eigenvec = pd.read_csv(r"C:\Users\conno\OneDrive\Desktop\plink_win64_20201019\1000genomes_common\last_PCA.eigenvec", header=0, delimiter=r"\s+")
####################################################################################################################
 # dataframe hold pcs and id
PC_df = pd.DataFrame( PCA_eigenvec.iloc[:,1:].values ,columns=['Sample name','PC 1', 'PC 2', 'PC 3','PC 4','PC 5','PC 6','PC 7','PC 8',
                                                'PC 9','PC 10','PC 11','PC 12','PC 13','PC 14','PC 15',
                                                'PC 16','PC 17','PC 18','PC 19','PC 20','PC 21','PC 22','PC 23',
                                                'PC 24','PC 25','PC 26','PC 27','PC 28','PC 29','PC 30'])#, index = features)
#####################################################################################################################
#tsv_file=r'C:\Users\conno\Downloads\igsr_samples.tsv'
#csv_table=pd.read_table(tsv_file,sep='\t')
#csv_table.to_csv(r'C:\Users\conno\Downloads\igsr_samples.csv',index=False)
#################################################################################
Labels = pd.read_csv(DATA_PATH.joinpath("igsr_samples.csv"),usecols=[0,2,3,4,5,6])
#################################################################################
# this is for merging the pop names into the pc dataframe
List_labels = Labels[Labels['Sample name'].isin(PC_df['Sample name'])]
 ################################################################################
final_df = pd.merge(PC_df,List_labels, how='inner',  on='Sample name')
final_df.infer_objects()
#################################################################################
relabeled = final_df.copy()
relabeled['Population code'].replace({'CHS': 'CHN', 'PUR': 'PRI', 'CDX': 'CHN', 'CLM': 'COL', 'IBS': 'ESP', 'PEL' :'PER', 'PJL': 'PAK',
       'KHV':'VNM', 'ACB': 'BHS' , 'GWD':'GMB' , 'ESN':'NGA', 'BEB': 'BGD', 'MSL':'SLE', 'STU': 'LKA', 'ITU':'IND', 'CEU':'GBR',
       'YRI':'NGA', 'CHB':'CHN', 'JPT':'JPN', 'LWK':'KEN', 'ASW': 'ZAF', 'MXL':'MEX', 'TSI':'ITA', 'GIH':'IND' },inplace=True)

relabeled['SampledFrom'] = relabeled['Population code'].replace({ 'STU': 'GBR', 'ITU':'GBR', 'CEU':'USA','ASW': 'USA', 'MXL':'USA', 'GIH':'USA' })
################################################################################
#find indina in uk
############################################################################
cont_names = relabeled['Superpopulation code'].unique()
contries_names = relabeled['Population code'].unique()
PC_LIST = relabeled.iloc[:,1:31]
cols = list(relabeled.columns)

################################################################################
exp_var_cumul = (PCA_eigenval/PCA_eigenval.sum()*100).cumsum()

var = px.area(x=exp_var_cumul.index, y=exp_var_cumul.iloc[:,0], labels={"x": "# Components", "y": "Explained Variance"})
############################################

# bootstrap theme
# https://bootswatch.com/spacelab/
#external_stylesheets = [dbc.themes.BOOTSTRAP]

#app = dash.Dash(__name__)#, external_stylesheets=external_stylesheets)

# change to app.layout if running as single page app instead
layout = html.Div(style={'backgroundColor': colors['background']},children=[
    html.H1('Analysis of genetic substructure using genome-wide SNP',
            style={'textAlign': 'center','color': colors['text']}),

    dbc.Container([
        dbc.Row(
            [
               # dbc.Col(controls,sm=2),
                dbc.Col(dcc.Graph(id="graph"), xl=8),
            ],
            align="center",
        ),
                #  html.P("Number of components:"),
               #   dcc.RangeSlider(id='slider',
                 # min=1,
                 # max=30,
                 # step=1,
                 #value=[1, 2],
                 #marks={i: 'PC {}'.format(i) for i in range(2,31)}) ])

                  dcc.Slider(id='slider', min=2, max=20, value=3, marks={i: 'PC {}'.format(i) for i in range(2,21)})])
                 #,style={ 'display': 'inline-block'})
])

################################################################################
@app.callback(
    Output(component_id='graph', component_property='figure'),
    #[Input(component_id='cont_dropdown', component_property='value'),
    Input(component_id='slider', component_property='value')#]
)


def update_slider(n_comp):
    ' this update the slider with the PCs of the dataset this is for the  first page'
    labels = {str(i): f"PC {i+1}"
              for i in range(n_comp)}
    fig3 = px.scatter_matrix(relabeled.iloc[:,1: n_comp + 1],dimensions= relabeled.columns[1:n_comp +1], color= relabeled['Population code'],
    color_discrete_map = color_discrete_map_pop

                             ,title='All the Principal Components plotted with the colours representing countries')
    fig3.update_traces(diagonal_visible=False)
    fig3.update_layout(width=1200, height = 800)

    return fig3
##################################################################################
#if __name__ == '__main__':
  #  app.run_server(port=8888,debug=True)


