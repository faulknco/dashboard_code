# -*- coding: utf-8 -*-

"""
@author: connor
"""
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import dash_bootstrap_components as dbc

# Connect to main app.py file
from app import app
#from app import server

# Connect to your app pages
from apps import firstpage, secondpage, home  #, thirdpage


#app.layout = html.Div([
 #   dcc.Location(id='url', refresh=False),
 #   html.Div([
 #       dcc.Link('First Page|', href='/apps/firstpage'),
 #       dcc.Link('Second Page', href='/apps/secondpage'),
 #   ], className="row"),
 #   html.Div(id='page-content', children=[])
#])


#@app.callback(Output('page-content', 'children'),
 #             [Input('url', 'pathname')])
#def display_page(pathname):
#    if pathname == '/apps/firstpage':
 #       return firstpage.layout
 #   if pathname == '/apps/secondpage':
 #       return secondpage.layout
 #   else:
 #       return "404 Page Error! Please choose a link"


#if __name__ == '__main__':
#    app.run_server(debug=False)

#import dash
#import dash_bootstrap_components as dbc


#app = dash.Dash(external_stylesheets=[dbc.themes.BOOTSTRAP])


# the style arguments for the sidebar. We use position:fixed and a fixed width
SIDEBAR_STYLE = {
    "position": "fixed",
    "top": 0,
    "left": 0,
    "bottom": 0,
    "width": "10rem",
    "padding": "2rem 1rem",
    #"background-color": "#f8f9fa",
}

# the styles for the main content position it to the right of the sidebar and
# add some padding.
CONTENT_STYLE = {
    "margin-left": "18rem",
    "margin-right": "2rem",
    "padding": "2rem 1rem",
}




sidebar = html.Div(
    [
        #html.H1("Connors Dashboard", className="display-4"),
       # html.Hr(),
       # html.P(
       #     "To flick through different pages", className="lead"
        #),
        dbc.Container([
        dbc.Row([
            dbc.Col(html.H1("Connor's Dashboard", className="text-right")
                    , className="mb-5 mt-5"),
                    html.P(
            "Use the buttons below to change page", className="lead"
        ),]),
        dbc.Nav(
            [
                dbc.NavLink("Home", href="/apps/home", active="exact"),
                dbc.NavLink("Page 1", href="/apps/firstpage", active="exact"),
                dbc.NavLink("Page 2", href="/apps/secondpage",active="exact" ),#active="exact"
            ],
            vertical="md",
            pills=True,
        ),
    ],
    style=SIDEBAR_STYLE,
)
        ])

content = html.Div(id="page-content", style=CONTENT_STYLE)

app.layout = html.Div([dcc.Location(id="url"), sidebar, content])


@app.callback(Output("page-content", "children"), [Input("url", "pathname")])
def render_page_content(pathname):
    if pathname == "/apps/home":
        return home.layout
    elif pathname == '/apps/firstpage':
        return firstpage.layout
    elif pathname == "/apps/secondpage":
        return secondpage.layout
     #If the user tries to reach a different page, return a 404 message
    return dbc.Jumbotron(
        [
            html.H1("404: Not found", className="text-danger"),
            html.Hr(),
            html.P(f"The pathname {pathname} was not recognised..."),
        ]
    )

if __name__ == '__main__':
    app.run_server(debug=False)
